function Cta() {
  return (
    <p>
      Try changing&nbsp;
      <span className="code">value</span>
      &nbsp;in&nbsp;
      <span className="code">SimpleStorage</span>.
    </p>
  );
}

export default Cta;
