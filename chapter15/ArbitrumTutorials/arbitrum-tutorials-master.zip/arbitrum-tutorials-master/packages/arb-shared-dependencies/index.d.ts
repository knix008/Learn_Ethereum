declare module 'arb-shared-dependencies'
